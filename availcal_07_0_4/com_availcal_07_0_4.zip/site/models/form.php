<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JLoader::register('AvailcalModelDarkperiod', JPATH_COMPONENT_ADMINISTRATOR . '/models/darkperiod.php');

/**
 * Darkperiod Form Model
 * 
 */
class AvailCalModelForm extends AvailCalModelDarkperiod {

   

}
