DROP TABLE IF EXISTS `#__avail_calendar`;
